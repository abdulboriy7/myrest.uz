let elBurger = document.querySelector(".header__burger");
let elSidebar = document.querySelector(".sidebar");

elBurger.addEventListener("click", ()=>{
    elSidebar.classList.toggle("sidebar_active");
    document.body.classList.toggle("body_active")
})